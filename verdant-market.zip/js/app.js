const DATA_URL = 'data/products.json';
const CART_KEY = 'verdant_cart';

function formatPrice(n){
  return '$' + Number(n).toFixed(2);
}

function discountedPrice(product){
  return product.price - (product.price * product.discountPercentage / 100);
}

function getCart(){
  const raw = localStorage.getItem(CART_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveCart(cart){
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
}

function addToCart(productId, qty){
  qty = qty || 1;
  const cart = getCart();
  const existing = cart.find(item => item.id === productId);
  if(existing){
    existing.qty += qty;
  }else{
    cart.push({ id: productId, qty: qty });
  }
  saveCart(cart);
}

function removeFromCart(productId){
  const cart = getCart().filter(item => item.id !== productId);
  saveCart(cart);
}

function updateCartQty(productId, qty){
  const cart = getCart();
  const existing = cart.find(item => item.id === productId);
  if(!existing) return;
  if(qty <= 0){
    removeFromCart(productId);
    return;
  }
  existing.qty = qty;
  saveCart(cart);
}

function cartItemCount(){
  return getCart().reduce((sum, item) => sum + item.qty, 0);
}

function updateCartCount(){
  const badges = document.querySelectorAll('[data-cart-count]');
  badges.forEach(el => { el.textContent = cartItemCount(); });
}

function showToast(message){
  let toast = document.querySelector('.toast');
  if(!toast){
    toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = '<span class="dot"></span><span class="toast-text"></span>';
    document.body.appendChild(toast);
  }
  toast.querySelector('.toast-text').textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2200);
}

async function loadProducts(){
  if(window._productCache) return window._productCache;
  const res = await fetch(DATA_URL);
  const json = await res.json();
  window._productCache = json.products;
  return json.products;
}

function starRating(rating){
  const rounded = Math.round(rating);
  return '★'.repeat(rounded) + '☆'.repeat(5 - rounded);
}

function productCard(product){
  const hasDiscount = product.discountPercentage > 0;
  const finalPrice = discountedPrice(product);
  return `
    <article class="product-card">
      <div class="product-thumb">
        <span class="badge">${product.category}</span>
        <a href="product.html?id=${product.id}">
          <img src="${product.thumbnail}" alt="${product.title}" loading="lazy">
        </a>
        <button class="quick-add" data-add-id="${product.id}" title="Add to cart">+</button>
      </div>
      <div class="product-info">
        <div class="product-cat">${product.brand ? product.brand : product.category}</div>
        <div class="product-title"><a href="product.html?id=${product.id}">${product.title}</a></div>
        <div class="product-price-row">
          <span class="price">${formatPrice(finalPrice)}</span>
          ${hasDiscount ? `<span class="price-old">${formatPrice(product.price)}</span>` : ''}
        </div>
        <div class="rating">${starRating(product.rating)} ${product.rating.toFixed(2)}</div>
      </div>
    </article>
  `;
}

function bindQuickAdd(container){
  container.querySelectorAll('[data-add-id]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const id = Number(btn.getAttribute('data-add-id'));
      addToCart(id, 1);
      showToast('Added to cart');
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
});
